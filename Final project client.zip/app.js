const { initializeApp } = require("firebase/app");
const { getAuth, createUserWithEmailAndPassword, signInWithEmailAndPassword } = require("firebase/auth");
const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser')


const app = express();

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({
	extended: true
}))
app.use(express.json())
app.use(express.urlencoded())
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

// FIREBASE INITIALIZATION
const firebaseConfig = {
  apiKey: "",
  authDomain: "themeal-122f3.firebaseapp.com",
  databaseURL: "https://themeal-122f3-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "themeal-122f3",
  storageBucket: "themeal-122f3.appspot.com",
  messagingSenderId: "1076684604622",
  appId: "1:1076684604622:web:bb2ec3f4b203f43271fc9f"
};
const firebaseApp = initializeApp(firebaseConfig);

// SEARCHING MEAL
app.get('/search', async (req, res) => {
  try {
    const searchQuery = req.query.search;
    let results = [];

    if (searchQuery) {
      const apiUrl = `https://www.themealdb.com/api/json/v1/1/search.php?s=${searchQuery}`;
      const response = await axios.get(apiUrl);

      if (response.data.meals) {
        results = response.data.meals;
      }
    }
    res.render('search', { results });
  } catch (error) {
    console.error('Error fetching data:', error.message);
    res.render('search', { results: [], error: 'Error fetching data' });
  }
});

// SIGN UP
app.get('/signup', (req, res) => {
  res.render('signup');
});

app.post('/signup', async (req, res) => {
  const { email, password } = req.body;
	let results = 'success'
	const firebaseAuth = getAuth(firebaseApp);
	createUserWithEmailAndPassword(firebaseAuth, email, password)
	.then((userCredential) => {
			const user = userCredential.user;
			console.log(user);
			return res.render('signup', {results})
	})
	.catch((error) => {
			const errorCode = error.code;
			const errorMessage = error.message;
	});
});

// LOGIN
app.get('/login', (req, res) => {
  let token = 'abcdefg';
  res.render('login', { token: token });
});


// app.post('/login', async (req, res) => {
// 	try {
// 		const { email, password } = req.body;
// 		const firebaseAuth = getAuth(firebaseApp);
// 		const userCredential = signInWithEmailAndPassword(firebaseAuth, email, password)
// 		const user = userCredential.user;
// 		console.log(user);
// 		let tokenAccess = user.accessToken;
// 		res.render('login', { token: tokenAccess });
// 	}
// 	catch (error) {
// 		const errorCode = error.code;
// 		const errorMessage = error.message;
// 		console.log(errorCode);
// 		console.log(errorMessage);
// 	}
// });

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});